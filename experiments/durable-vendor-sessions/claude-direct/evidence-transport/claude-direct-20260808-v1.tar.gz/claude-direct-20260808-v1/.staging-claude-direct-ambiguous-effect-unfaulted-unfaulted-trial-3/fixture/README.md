# Claude direct durability fixture

The controlled effect appends to effects.jsonl.
